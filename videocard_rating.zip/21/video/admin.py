from django.contrib import admin
from django.contrib import admin
from .models import VideoCard
# Register your models here.

@admin.register(VideoCard)
class VideoCardAdmin(admin.ModelAdmin):
    list_display = ('name', 'manufacturer', 'core_clock', 'memory', 'rating')
