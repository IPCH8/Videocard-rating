from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy
from django.db.models import Q
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.contrib.auth import logout, login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django import forms
from .models import Post, Comment, VideoCard
from django.http import JsonResponse


# ВІДОБРАЖЕННЯ СПИСКУ ВІДЕОКАРТ


def videocard_list(request):
    query = request.GET.get('q', '').strip()
    mfr = request.GET.get('mfr', '').strip()
    videocards = VideoCard.objects.all().order_by('name')
    if query:
        videocards = videocards.filter(Q(name__icontains=query) | Q(manufacturer__icontains=query))
    if mfr:
        videocards = videocards.filter(manufacturer__iexact=mfr)
    manufacturers = VideoCard.objects.values_list('manufacturer', flat=True).distinct().order_by('manufacturer')

    # Форма додавання коментаря
    if request.method == 'POST':
        if 'delete_comment' in request.POST:
            # Видалення коментаря
            comment_id = request.POST['delete_comment']
            try:
                comment = Comment.objects.get(pk=comment_id, author=request.user)
                comment.delete()
            except Comment.DoesNotExist:
                pass
        elif 'text' in request.POST:
            # Додавання нового коментаря
            text = request.POST['text'].strip()
            if text:
                Comment.objects.create(
                    author=request.user,
                    text=text
                    
                )

    comments = Comment.objects.all().order_by('-created_at') 

    return render(request, 'video/videocard_list.html', {
        'videocards': videocards,
        'q': query,
        'mfr': mfr,
        'manufacturers': manufacturers,
        'comments': comments
    })



# CLASS-BASED VIEWS ДЛЯ ВІДЕОКАРТ

class VideoCardListView(ListView):
    model = VideoCard
    template_name = 'video/videocard_list.html'
    context_object_name = 'videocards'
    paginate_by = 20 

    def get_queryset(self):
        qs = super().get_queryset().order_by('name')
        q = self.request.GET.get('q', '').strip()
        mfr = self.request.GET.get('mfr', '').strip()
        if q:
            qs = qs.filter(Q(name__icontains=q) | Q(manufacturer__icontains=q))
        if mfr:
            qs = qs.filter(manufacturer__iexact=mfr)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['q'] = self.request.GET.get('q', '').strip()
        ctx['mfr'] = self.request.GET.get('mfr', '').strip()
        ctx['manufacturers'] = VideoCard.objects.values_list('manufacturer', flat=True).distinct().order_by('manufacturer')
        ctx['comments'] = Comment.objects.all().order_by('-created_at')
        return ctx

class VideoCardCreateView(LoginRequiredMixin, CreateView):
    model = VideoCard
    fields = ['name', 'manufacturer', 'core_clock', 'memory', 'rating']
    template_name = 'video/videocard_form.html'
    success_url = reverse_lazy('videocard-list')

    def form_valid(self, form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

class OwnerRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        obj = self.get_object()
        return obj.owner_id == self.request.user.id

class VideoCardUpdateView(LoginRequiredMixin, OwnerRequiredMixin, UpdateView):
    model = VideoCard
    fields = ['name', 'memory', 'manufacturer']
    template_name = 'video/videocard_form.html'
    success_url = reverse_lazy('videocard-list')

class VideoCardDeleteView(LoginRequiredMixin, OwnerRequiredMixin, DeleteView):
    model = VideoCard
    template_name = 'video/videocard_confirm_delete.html'
    success_url = reverse_lazy('videocard-list')


# РЕЄСТРАЦІЯ ТА ВИХІД

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('videocard-list')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('videocard-list')


# ФОРМА ДЛЯ КОМЕНТАРІВ

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ["text"]


# РЕДАГУВАННЯ ТА ВИДАЛЕННЯ КОМЕНТАРІВ

@login_required
def edit_comment(request, pk):
    comment = get_object_or_404(Comment, pk=pk, author=request.user)
    if request.method == "POST":
        form = CommentForm(request.POST, instance=comment)
        if form.is_valid():
            form.save()
            return redirect("videocard-list")
    else:
        form = CommentForm(instance=comment)
    return render(request, "video/videocard_list.html", {"form": form})

@login_required
def delete_comment(request, pk):
    comment = get_object_or_404(Comment, pk=pk, author=request.user)
    if request.method == "POST":
        comment.delete()
    return redirect('videocard-list')


@login_required
def add_comment(request):
    if request.method == "POST" and request.headers.get("X-Requested-With") == "XMLHttpRequest":
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.author = request.user
            comment.save()
            return JsonResponse({
                "author": comment.author.username,
                "text": comment.text,
                "created_at": comment.created_at.strftime("%d.%m.%Y %H:%M")
            })
    return JsonResponse({"error": "Invalid request"}, status=400)

def post_detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    comments = post.comments.all()

    # Видалення коментаря
    if request.method == "POST" and "delete_comment" in request.POST:
        comment_id = request.POST["delete_comment"]
        comment = get_object_or_404(Comment, pk=comment_id, author=request.user)
        comment.delete()
        return redirect(request.path)  # перезавантаження сторінки

    # Додавання коментаря
    if request.method == "POST" and "text" in request.POST:
        if not request.user.is_authenticated:
            return redirect("login")
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.author = request.user
            comment.save()
            return redirect(request.path)
    else:
        form = CommentForm()

    return render(request, "post_detail.html", {"post": post, "comments": comments, "form": form})