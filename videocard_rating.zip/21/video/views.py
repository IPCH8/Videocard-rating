from django.shortcuts import render
from django.shortcuts import render
from .models import VideoCard
from django.db.models import Q
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import ListView, CreateView, UpdateView, DeleteView

# Create your views here.

def videocard_list(request):
    videocards = VideoCard.objects.all().order_by('-rating')
    return render(request, 'video/videocard_list.html', {'videocards': videocards})

class VideoCardListView(ListView):
    model = VideoCard
    template_name = 'video/videocard_list.html'
    context_object_name = 'videocards'
    paginate_by = 20 

    def get_queryset(self):
        qs = super().get_queryset().order_by('name')
        q = self.request.GET.get('q', '').strip()
        mfr = self.request.GET.get('mfr', '').strip()
        if q:
            qs = qs.filter(Q(name__icontains=q) | Q(manufacturer__icontains=q))
        if mfr:
            qs = qs.filter(manufacturer__iexact=mfr)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['q'] = self.request.GET.get('q', '').strip()
        ctx['mfr'] = self.request.GET.get('mfr', '').strip()
        ctx['manufacturers'] = (
            VideoCard.objects.values_list('manufacturer', flat=True)
            .distinct().order_by('manufacturer')
        )
        return ctx

class VideoCardCreateView(LoginRequiredMixin, CreateView):
    model = VideoCard
    fields = ['name', 'manufacturer', 'core_clock', 'memory', 'rating']
    template_name = 'video/videocard_form.html'
    success_url = reverse_lazy('videocard-list')

    def form_valid(self, form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

class OwnerRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        obj = self.get_object()
        return obj.owner_id == self.request.user.id

class VideoCardUpdateView(LoginRequiredMixin, OwnerRequiredMixin, UpdateView):
    model = VideoCard
    fields = ['name', 'memory', 'manufacturer']
    template_name = 'video/videocard_form.html'
    success_url = reverse_lazy('videocard-list')

class VideoCardDeleteView(LoginRequiredMixin, OwnerRequiredMixin, DeleteView):
    model = VideoCard
    template_name = 'video/videocard_confirm_delete.html'
    success_url = reverse_lazy('videocard-list')