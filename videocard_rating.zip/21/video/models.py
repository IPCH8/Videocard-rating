from django.conf import settings
from django.db import models
from django.db import models

class VideoCard(models.Model):
    name = models.CharField(max_length=100)
    manufacturer = models.CharField(max_length=50)
    core_clock = models.IntegerField(help_text="MHz")
    memory = models.IntegerField(help_text="GB")
    rating = models.FloatField(help_text="0-10")

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='videocards',
        null=True, blank=True
    )

    def __str__(self):
        return f"{self.name} ({self.manufacturer})"


