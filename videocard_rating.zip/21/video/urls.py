from django.urls import path
from . import views
from .views import (
    VideoCardListView, VideoCardCreateView,
    VideoCardUpdateView, VideoCardDeleteView
)

urlpatterns = [
    path('', VideoCardListView.as_view(), name='videocard-list'),
    path('add/', VideoCardCreateView.as_view(), name='videocard-add'),
    path('<int:pk>/edit/', VideoCardUpdateView.as_view(), name='videocard-edit'),
    path('<int:pk>/delete/', VideoCardDeleteView.as_view(), name='videocard-delete'),
    
]
